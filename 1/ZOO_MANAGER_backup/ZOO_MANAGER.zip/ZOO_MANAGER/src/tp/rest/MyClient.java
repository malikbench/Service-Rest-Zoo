package tp.rest;

import tp.model.Animal;
import tp.model.Cage;
import tp.model.Center;
import tp.model.Position;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.util.JAXBSource;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;
import java.util.LinkedList;
import java.util.Map;
import java.util.UUID;
import java.util.Random;


public class MyClient {
    private Service service;
    private JAXBContext jc;

    private static final QName qname = new QName("", "");
    private static final String url = "http://127.0.0.1:8084";

    public MyClient() {
        try {
            jc = JAXBContext.newInstance(Center.class, Cage.class, Animal.class, Position.class);
        } catch (JAXBException je) {
            System.out.println("Cannot create JAXBContext " + je);
        }
    }
    /**
     * Ajoute un animal au centre
     */
    public void add_animal(Animal animal) throws JAXBException {
        printSource(getSource(url + "/animals", "POST", new JAXBSource(jc, animal)));
    }

    /**
     * Ajoute une cage au centre
     */
    public void add_cage(Cage cage) throws JAXBException {
        printSource(getSource(url + "/cages", "POST", new JAXBSource(jc, cage)));
    }

    /**
     * Edite tous les animaux
     */
    public void edit_all_animals(Animal animal) throws JAXBException {
        printSource(getSource(url + "/animals", "PUT", new JAXBSource(jc, animal)));
    }


    /**
     * Supprime tous les animaux du centre
     */
    public void delete_all_animals() throws JAXBException {
        printSource(getSource(url + "/animals", "DELETE", null));
    }


    /**
     * Retourne tout les animaux du centre
     */
    public void get_animals() {
        printSource(getSource(url + "/animals", "GET", null));
    }

    /**
     * Supprime une cage identifiée par son nom
     */
    public void delete_cage_with_name(String name) throws JAXBException {
        printSource(getSource(url + "/cages/" + name, "DELETE", null));
    }

    /**
     * Retourne l'animal identifiée par son id
     */
    public void get_animal_with_id(UUID id) {
        printSource(getSource(url + "/animals/" + id, "GET", null));
    }

    /**
     * Supprime un animal identifié par son id
     */
    public void delete_animal_with_id(UUID id) throws JAXBException {
        printSource(getSource(url + "/animals/" + id, "DELETE", null));
    }


    private Source getSource(String url, String method, Source body) {
        // Initialisation du service
        service = Service.create(qname);
        service.addPort(qname, HTTPBinding.HTTP_BINDING, url);

        // Création du dispatcher
        Dispatch<Source> dispatcher = service.createDispatch(qname, Source.class, Service.Mode.MESSAGE);
        Map<String, Object> requestContext = dispatcher.getRequestContext();
        requestContext.put(MessageContext.HTTP_REQUEST_METHOD, method);

        // Retourne le résultat de la requete
        return dispatcher.invoke(body);
    }

    public void printSource(Source s) {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(s, new StreamResult(System.out));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String args[]) throws Exception {
        MyClient client = new MyClient();
        //1. Affichez l'ensemble des animaux
        System.out.println("Affichez l'ensemble des animaux");
        client.get_animals();
        System.out.println();

        //2. Supprimez touts les animaux
        System.out.println("Supprimez tous les animaux");
        client.delete_all_animals();
        client.get_animals();
        System.out.println();

        //3. Ajoutez un Panda à Rouen
        System.out.println("Ajoutez un Panda à Rouen");
        client.add_cage(new Cage("Rouen", new Position(49.443889, 1.103333), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Pando", "Rouen", "Panda", UUID.randomUUID()));
        System.out.println();

        //4. Ajoutez un Hocco unicorne à Paris
        System.out.println("Ajoutez un  Hocco unicorne à Paris");
        client.add_cage(new Cage("Paris", new Position(48.856578, 2.351828), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Bob", "Paris", "Hocco unicorne", UUID.randomUUID()));
        System.out.println();

        //5. Affichez tous les animaux
        System.out.println("Affichez l'ensemble des animaux");
        client.get_animals();
        System.out.println();


        //6. Modifiez l'ensemble des animaux par un Lagotriche à queue jaune à Rouen
        System.out.println("Modifiez l'ensemble des animaux par un Lagotriche à queue jaune à Rouen ");
        client.edit_all_animals(new Animal("Bob", "Rouen", "Lagotriche à queue jaune", UUID.randomUUID()));
        System.out.println();


        //7. Affichez l'ensemble des animaux
        System.out.println("Affichez l'ensemble des animaux");
        client.get_animals();
        System.out.println();


        //8. Ajoutez une Océanite de Matsudaira en Somalie (Latitude : 2.333333 ; Longitude : 48.85)
        System.out.println("Ajoutez une Océanite de Matsudaira en Somalie ");
        client.add_cage(new Cage("Somalie", new Position(2.333333, 48.85), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Bob", "Somalie", "Océanite de Matsudaira", UUID.randomUUID()));
        System.out.println();

        //9. Ajoutez un Ara de Spix à Rouen (Latitude : 49.443889 ; Longitude : 1.103333)
        System.out.println("Ajoutez un Ara de Spix à Rouen");
        client.add_animal(new Animal("Bob", "Paris", "Ara de Spix", UUID.randomUUID()));
        System.out.println();

        //10. Ajoutez un Galago de Rondo à Bihorel (Latitude : 49.455278 ; Longitude : 1.116944)
        System.out.println("Ajoutez un Ajoutez un Galago de Rondo à Bihorel");
        UUID galadoId = UUID.randomUUID();
        client.add_cage(new Cage("Bihorel", new Position(49.455278, 1.116944), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Bob", "Bihorel", "Galago de Rondo", UUID.randomUUID()));
        System.out.println();

        //11. Ajoutez une Palette des Sulu à Londres (Latitude : 51.504872 ; Longitude : ­0.07857)
        System.out.println("Ajoutez une Palette des Sulu à Londres");
        client.add_cage(new Cage("Londres", new Position(51.504872, 0.07857), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Bob", "Londres", "Palette des Sulu", UUID.randomUUID()));
        System.out.println();

        //12. Ajoutez un Kouprey à Paris (Latitude : 48.856578 ; Longitude : 2.351828)
        System.out.println("Ajoutez un Kouprey à Paris");
        client.add_animal(new Animal("Bob", "Paris", "Kouprey", UUID.randomUUID()));
        System.out.println();

        //13. Ajoutez un Tuit­tuit à Paris (Latitude : 48.856578 ; Longitude : 2.351828)
        System.out.println("Ajoutez un Tuit-tuit à Paris");
        client.add_animal(new Animal("Bob", "Paris", "Tuit\u00ADtuit", UUID.randomUUID()));
        System.out.println();

        //14. Ajoutez une Saïga au Canada (Latitude : 43.2 ; Longitude : ­80.38333)
        System.out.println("Ajoutez une Saïga des Sulu au Canada");
        client.add_cage(new Cage("Londres", new Position(43.2, 80.38333), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Bob", "Canada", "Saïga", UUID.randomUUID()));
        System.out.println();

        //15. Ajoutez un Inca de Bonaparte à Porto­Vecchio (Latitude : 41.5895241 ; Longitude : 9.2627)
        System.out.println("Ajoutez un Inca de Bonaparte à Porto-Vecchio");
        client.add_cage(new Cage("Porto-Vecchio", new Position(41.5895241, 9.2627), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Bob", "Porto-Vecchio", "Inca de Bonaparte", UUID.randomUUID()));
        System.out.println();

        //16. Affichez l'ensemble des animaux
        System.out.println("Affichez l'ensemble des animaux");
        client.get_animals();
        System.out.println();

        //17. Ajoutez un Râle de Zapata à Montreux (Latitude : 46.4307133; Longitude : 6.9113575)
        System.out.println("Ajoutez un Râle de Zapata à Montreux");
        client.add_cage(new Cage("Montreux", new Position( 46.4307133, 6.9113575), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Bob", "Montreux", "Râle de Zapata", UUID.randomUUID()));
        System.out.println();

        //18. Ajoutez un Rhinocéros de Java à Villers­Bocage (Latitude : 50.0218 ; Longitude : 2.3261)
        System.out.println("Ajoutez un Rhinocéros de Java à Villers\u00ADBocage");
        client.add_cage(new Cage(" Villers\u00ADBocage", new Position(  50.0218,  2.3261), 20, new LinkedList<Animal>()));
        client.add_animal(new Animal("Bob", " Villers\u00ADBocage", " Rhinocéros de Java", UUID.randomUUID()));
        System.out.println();

        //19. Ajoutez 101 Dalmatiens dans une cage aux USA
        System.out.println("Ajoutez 101 Dalmatiens dans une cage aux USA");
        for (int i = 0; i < 100; i++) {
            client.add_animal(new Animal("Dalmatien " + (i + 1), "usa", "Dalmatien", UUID.randomUUID()));
        }
        System.out.println();

        //20. Affichez l'ensemble des animaux
        System.out.println("Affichez l'ensemble des animaux");
        client.get_animals();
        System.out.println();

        //21. Supprimez tous les animaux de Paris
        System.out.println("Supprimez tous les animaux de Paris");
        client.delete_cage_with_name("Paris");
        System.out.println();

        //22. Affichez l'ensemble des animaux
        System.out.println("Affichez l'ensemble des animaux");
        client.get_animals();
        System.out.println();

        //23. Recherchez le Galago de Rondo
        System.out.println("Recherchez le Galago de Rondo");
        client.get_animal_with_id(galadoId);
        System.out.println();

        //24. Supprimez le Galago de Rondo
        System.out.println("Supprimez le Galago de Rondo");
        client.delete_animal_with_id(galadoId);
        System.out.println();

        //25. Supprimez à nouveau le Galago de Rondo
        System.out.println("Supprimez le Galago de Rondo");
        client.delete_animal_with_id(galadoId);
        System.out.println();

        //26. Affichez l'ensemble des animaux
        System.out.println("Affichez l'ensemble des animaux");
        client.get_animals();
        System.out.println();

        //33. Supprimez touts les animaux
        System.out.println("Supprimez tous les animaux");
        client.delete_all_animals();
        client.get_animals();
        System.out.println();

        //34. Affichez l'ensemble des animaux
        System.out.println("Affichez l'ensemble des animaux");
        client.get_animals();
        System.out.println();
    }
}

package tp.rest;

import java.util.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.util.JAXBSource;
import javax.xml.transform.Source;
import javax.xml.ws.Endpoint;
import javax.xml.ws.Provider;
import javax.xml.ws.Service;
import javax.xml.ws.ServiceMode;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.WebServiceProvider;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;
import javax.xml.ws.http.HTTPException;

import tp.model.*;
import tp.model.AnimalNotFoundException;
import tp.model.CageNotFoundException;
import tp.model.CenterException;

@WebServiceProvider
@ServiceMode(value = Service.Mode.MESSAGE)
public class MyServiceTP implements Provider<Source> {

    public final static String url = "http://127.0.0.1:8084/";

    public static void main(String args[]) {
        Endpoint e = Endpoint.create(HTTPBinding.HTTP_BINDING, new MyServiceTP());

        e.publish(url);
        System.out.println("Service started, listening on " + url);
        // pour arrêter : e.stop();
    }

    private JAXBContext jc;

    @javax.annotation.Resource(type = Object.class)
    protected WebServiceContext wsContext;

    private Center center = new Center(new LinkedList<>(), new Position(49.30494d, 1.2170602d), "Biotropica");

    public MyServiceTP() {
        try {
            jc = JAXBContext.newInstance(Center.class, Cage.class, Animal.class, Position.class);
        } catch (JAXBException je) {
            System.out.println("Exception " + je);
            throw new WebServiceException("Cannot create JAXBContext", je);
        }

        // Fill our center with some animals
        Cage usa = new Cage(
                "usa",
                new Position(49.305d, 1.2157357d),
                25,
                new LinkedList<>(Arrays.asList(
                        new Animal("Tic", "usa", "Chipmunk", UUID.randomUUID()),
                        new Animal("Tac", "usa", "Chipmunk", UUID.randomUUID())
                ))
        );


        Cage amazon = new Cage(
                "amazon",
                new Position(49.305142d, 1.2154067d),
                15,
                new LinkedList<>(Arrays.asList(
                        new Animal("Canine", "amazon", "Piranha", UUID.randomUUID()),
                        new Animal("Incisive", "amazon", "Piranha", UUID.randomUUID()),
                        new Animal("Molaire", "amazon", "Piranha", UUID.randomUUID()),
                        new Animal("De lait", "amazon", "Piranha", UUID.randomUUID())
                ))
        );

        center.getCages().addAll(Arrays.asList(usa, amazon));
    }

    public Source invoke(Source source) {
        MessageContext mc = wsContext.getMessageContext();
        String path = (String) mc.get(MessageContext.PATH_INFO);
        String method = (String) mc.get(MessageContext.HTTP_REQUEST_METHOD);

        // determine the targeted ressource of the call
        try {
            String[] path_parts = path.split("/");


            // "/animals" target - Redirect to the method in charge of managing this sort of call.
            if (path.startsWith("animals")) {
                switch (path_parts.length) {
                    case 1:
                        return this.animalsCrud(method, source);
                    case 2:
                        return this.animalCrud(method, source, path_parts[1]);
                    default:
                        throw new HTTPException(404);
                }
            }

            // "/cages" target - Redirect to the method in charge of managing this sort of call. (ADDITIONAL FEATURES)
            else if (path.startsWith("cages")) {
                if (path_parts.length == 1) {
                    return this.cagesCrud(method, source);
                } else if (path_parts.length == 2) {
                    return this.cageCrud(method, source, path_parts[1]);
                }
            }

            // "/find" target - Redirect to the method in charge of managing this sort of call.
            else if (path.startsWith("find") && path_parts.length == 3) {
                return this.findCrud(method, source, path_parts[1], path_parts[2]);
            }

        } catch (JAXBException e) {
            throw new HTTPException(500);
        }

        throw new HTTPException(404);
    }


    /**
     * Method bound to calls on /animals/{something}
     */
    private Source animalCrud(String method, Source source, String animal_id) throws JAXBException {
        try {
            switch (method) {
                case "GET":
                    return new JAXBSource(this.jc, center.findAnimalById(UUID.fromString(animal_id)));
                case "POST":
                    return new JAXBSource(this.jc, center.createAnimalById(unmarshalAnimal(source), UUID.fromString(animal_id)));
                case "PUT":
                    return new JAXBSource(this.jc, center.editAnimalById(unmarshalAnimal(source), UUID.fromString(animal_id)));
                case "DELETE":
                    return new JAXBSource(this.jc, center.deleteAnimalById(UUID.fromString(animal_id)));
                default:
                    throw new HTTPException(404);
            }
        } catch (CenterException e) {
            return new JAXBSource(this.jc, new CenterException());
        }
    }

    /**
     * Method bound to calls on /animals
     */
    private Source animalsCrud(String method, Source source) throws JAXBException {
        try {
            switch (method) {
                case "GET":
                    return new JAXBSource(this.jc, center);
                case "POST":
                    return new JAXBSource(this.jc, center.addAnimal(unmarshalAnimal(source)));
                case "PUT":
                    return new JAXBSource(this.jc, center.editAllAnimals(unmarshalAnimal(source)));
                case "DELETE":
                    return new JAXBSource(this.jc, center.deleteAllAnimals());
                default:
                    throw new HTTPException(404);
            }
        } catch (CenterException e) {
            return new JAXBSource(this.jc, new CenterException());
        }
    }

    /**
     * Method bound to calls on /cages/{something}
     */
    private Source cageCrud(String method, Source source, String cage_name) throws JAXBException {
        try {
            switch (method) {
                case "GET":
                    return new JAXBSource(this.jc, center.findCageByName(cage_name));
                case "PUT":
                    return new JAXBSource(this.jc, center.editCageByName(unmarshalCage(source), cage_name));
                case "DELETE":
                    return new JAXBSource(this.jc, center.deleteCageByName(cage_name));
                default:
                    throw new HTTPException(404);
            }
        } catch (CageNotFoundException e) {
            return new JAXBSource(this.jc, new CageNotFoundException(e.getMessage()));
        }
    }

    /**
     * Method bound to calls on /cages
     */
    private Source cagesCrud(String method, Source source) throws JAXBException {
        try {
            switch (method) {
                case "POST":
                    return new JAXBSource(this.jc, center.addCage(unmarshalCage(source)));
                case "PUT":
                    return new JAXBSource(this.jc, center.editAllCages(unmarshalCage(source)));
                case "DELETE":
                    return new JAXBSource(this.jc, center.deleteAllCages());
                default:
                    throw new HTTPException(404);
            }
        } catch (CageNotFoundException e) {
            return new JAXBSource(this.jc, new CageNotFoundException(e.getMessage()));
        }
    }

    /**
     * Method bound to calls on /find/byName/{something}
     * /find/at/{something}
     * /find/near/{something}
     */
    private Source findCrud(String method, Source source, String search, String searchValue) throws JAXBException {
        if (!method.equals("GET")) {
            throw new HTTPException(404);
        }

        try {
            switch (search) {
                case "byName":
                    return new JAXBSource(this.jc, center.findAnimalByName(searchValue));
                default:
                    throw new HTTPException(404);
            }
        } catch (AnimalNotFoundException e) {
            return new JAXBSource(this.jc, new Exception());
        }
    }

    /**
     * Unmarshal Source to Animal
     */
    private Animal unmarshalAnimal(Source source) throws JAXBException {
        return (Animal) this.jc.createUnmarshaller().unmarshal(source);
    }

    /**
     * Unmarshal Source to Animal
     */
    private Cage unmarshalCage(Source source) throws JAXBException {
        Cage cage = (Cage) this.jc.createUnmarshaller().unmarshal(source);

        // Vérifie que la liste est instanciée suite au unmarshal
        if (cage.getResidents() == null) {
            cage.setResidents(new LinkedList<Animal>());
        }

        return cage;
    }
}

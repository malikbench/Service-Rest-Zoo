package tp.model;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.Collection;
import java.util.LinkedList;
import java.util.UUID;

@XmlRootElement
public class Center {

    Collection<Cage> cages;
    Position position;
    String name;

    public Center() {
        cages = new LinkedList<>();
    }

    public Center(Collection<Cage> cages, Position position, String name) {
        this.cages = cages;
        this.position = position;
        this.name = name;
    }

    public Animal createAnimalById(Animal animal, UUID uuid) throws CenterException {
        // Création du nouvel animal avec l'UUID passé en paramètres
        Animal createdAnimal = new Animal(animal.getName(), animal.getCage(), animal.getSpecies(), uuid);
        // Ajout de l'animal dans sa cage
        addAnimal(createdAnimal);
        return createdAnimal;
    }

    public Animal editAnimalById(Animal editedAnimal, UUID uuid) throws AnimalNotFoundException {
        // Récupération de l'animal à modifier
        Animal animal = findAnimalById(uuid);
        // Modifie les caractéristiques de l'animal par les caractéristiques de l'animal passé en paramètres
        animal.setName(editedAnimal.getName());
        animal.setCage(editedAnimal.getCage());
        animal.setSpecies(editedAnimal.getSpecies());
        return animal;
    }

    public Center deleteAnimalById(UUID uuid) throws CenterException {
        // Récupération de l'animal à supprimer
        Animal animal = findAnimalById(uuid);
        // Suppression de l'animal dans la cage dans lequel il est
        findCageByName(animal.getCage()).getResidents().remove(animal);
        return this;
    }


    public Center addAnimal(Animal animal) throws CenterException {
        // Récupération de la cage du nouvel animal
        Cage cage = findCageByName(animal.getCage());
        // Ajout de l'animal dans sa cage
        cage.getResidents().add(animal);

        return this;
    }

    public Center editAllAnimals(Animal animal) throws CageNotFoundException {
        // Récupération de la nouvelle cage désirée
        Cage cage = findCageByName(animal.getCage());
        Collection<Animal> animals = new LinkedList<Animal>();
        // Récupération de l'ensemble des animaux
        cages.forEach(c -> animals.addAll(c.getResidents()));
        // Vide toutes les cages
        deleteAllAnimals();
        // Ajout de l'ensemble des animaux dans la cage désirée
        cage.setResidents(animals);
        // Modification des caractéristiques de l'ensemble des animaux
        cage.getResidents().forEach(a -> {
            a.setName(animal.getName());
            a.setCage(animal.getCage());
            a.setSpecies(animal.getSpecies());
        });
        return this;
    }

    public Center deleteAllAnimals() {
        cages.forEach(cage -> cage.getResidents().clear());

        return this;
    }

    public Animal findAnimalById(UUID uuid) throws AnimalNotFoundException {
        return this.cages.stream()
                .map(Cage::getResidents)
                .flatMap(Collection::stream)
                .filter(animal -> uuid.equals(animal.getId()))
                .findFirst()
                .orElseThrow(() -> new AnimalNotFoundException("No animal found with name : " + name));
    }

    public Animal findAnimalByName(String name) throws AnimalNotFoundException {
        return this.cages.stream()
                .map(Cage::getResidents)
                .flatMap(Collection::stream)
                .filter(animal -> name.equals(animal.getName()))
                .findFirst()
                .orElseThrow(() -> new AnimalNotFoundException("No animal found with name : " + name));
    }

    public Cage findCageByName(String name) throws CageNotFoundException {
        return cages.stream()
                .filter(cage -> cage.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElseThrow(() -> new CageNotFoundException("No cage found with name : " + name));
    }

    public Cage editCageByName(Cage editedCage, String cageName) throws CageNotFoundException {
        // Récupération de la cage à modifier
        Cage cage = findCageByName(cageName);
        // Modification des caractéristiques de la cage par les caractéristiques de la cage passée en paramètres
        cage.setCapacity(editedCage.getCapacity());
        cage.setPosition(editedCage.getPosition());
        cage.setResidents(editedCage.getResidents());
        return cage;
    }

    public Center deleteCageByName(String name) throws CageNotFoundException {
        // Récupération de la cage à supprimer
        Cage cage = findCageByName(name);
        // Suppression de la cage du centre
        cages.remove(cage);
        return this;
    }


    public Center addCage(Cage cage) throws CageNotFoundException {
        cages.add(cage);

        return this;
    }

    public Center editAllCages(Cage cage) {
        // Pour chaque cage
        cages.forEach(c -> {
            // Modification des caractéristiques de la cage par les caractéristiques de la cage passée en paramètres
            c.setPosition(cage.getPosition());
            c.setCapacity(cage.getCapacity());
        });

        return this;
    }

    public Center deleteAllCages() {
        cages.clear();

        return this;
    }

    public Collection<Cage> getCages() {
        return cages;
    }

    public Position getPosition() {
        return position;
    }

    public String getName() {
        return name;
    }

    public void setCages(Collection<Cage> cages) {
        this.cages = cages;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public void setName(String name) {
        this.name = name;
    }
}

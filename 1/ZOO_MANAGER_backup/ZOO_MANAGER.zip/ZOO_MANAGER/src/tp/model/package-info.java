@javax.xml.bind.annotation.XmlSchema(namespace = "m1GIL:rest:tp")
package tp.model;

package tp.model;

public class CageNotFoundException extends CenterException {

    private static final long serialVersionUID = 1L;

    public CageNotFoundException(String message) {
        super(message);
    }

}